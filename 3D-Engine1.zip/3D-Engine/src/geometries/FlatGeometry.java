package geometries;

public interface FlatGeometry {
}
